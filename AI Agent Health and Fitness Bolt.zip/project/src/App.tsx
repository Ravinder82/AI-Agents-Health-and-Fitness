import React, { useState } from "react";
import { UserProfile } from "@/types/user";
import { UserProfileForm } from "@/components/UserProfileForm";
import { HealthPlanDisplay } from "@/components/HealthPlanDisplay";
import { ApiKeyInput } from "@/components/ApiKeyInput/ApiKeyInput";
import { ErrorMessage } from "@/components/ErrorMessage/ErrorMessage";
import { LoadingSpinner } from "@/components/LoadingSpinner/LoadingSpinner";
import { useHealthPlan } from "@/hooks/useHealthPlan";

export default function App() {
  const [apiKey, setApiKey] = useState("");
  const { healthPlan, loading, error, generatePlan } = useHealthPlan();

  async function handleSubmit(data: UserProfile) {
    await generatePlan(apiKey, data);
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="container mx-auto px-4 py-8">
        <h1 className="text-4xl font-bold text-center mb-8">
          🏋️‍♂️ AI Health & Fitness Planner
        </h1>

        <div className="max-w-4xl mx-auto">
          <ApiKeyInput
            apiKey={apiKey}
            onChange={setApiKey}
            error={error}
          />

          {error && <ErrorMessage message={error} />}

          <div className="bg-white p-6 rounded-lg shadow-md">
            <h2 className="text-xl font-semibold mb-6">Your Profile</h2>
            <UserProfileForm onSubmit={handleSubmit} />
          </div>

          {loading && <LoadingSpinner />}

          {healthPlan && <HealthPlanDisplay plan={healthPlan} />}
        </div>
      </div>
    </div>
  );
}