import React from 'react';

interface ApiKeyInputProps {
  apiKey: string;
  onChange: (value: string) => void;
  error?: string | null;
}

export function ApiKeyInput({ apiKey, onChange, error }: ApiKeyInputProps) {
  return (
    <div className="bg-white p-6 rounded-lg shadow-md mb-8">
      <h2 className="text-xl font-semibold mb-4">API Configuration</h2>
      <input
        type="password"
        placeholder="Enter your Google Gemini API key"
        value={apiKey}
        onChange={(e) => onChange(e.target.value)}
        className="w-full p-2 border rounded-md mb-2"
      />
      <p className="text-sm text-gray-600">
        Get your free API key from{" "}
        <a
          href="https://makersuite.google.com/app/apikey"
          target="_blank"
          rel="noopener noreferrer"
          className="text-blue-600 hover:underline"
        >
          Google AI Studio
        </a>
      </p>
      {error && (
        <p className="text-sm text-red-600 mt-2">{error}</p>
      )}
    </div>
  );
}