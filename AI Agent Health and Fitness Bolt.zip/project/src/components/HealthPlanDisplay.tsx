import { HealthPlan } from "@/types/user";
import { useState } from "react";

interface HealthPlanDisplayProps {
  plan: HealthPlan;
}

export function HealthPlanDisplay({ plan }: HealthPlanDisplayProps) {
  const [activeTab, setActiveTab] = useState<"diet" | "fitness">("diet");

  return (
    <div className="mt-8">
      <div className="flex space-x-4 mb-4">
        <button
          onClick={() => setActiveTab("diet")}
          className={`px-4 py-2 rounded-md ${
            activeTab === "diet"
              ? "bg-primary text-white"
              : "bg-gray-100 text-gray-700"
          }`}
        >
          Diet Plan
        </button>
        <button
          onClick={() => setActiveTab("fitness")}
          className={`px-4 py-2 rounded-md ${
            activeTab === "fitness"
              ? "bg-primary text-white"
              : "bg-gray-100 text-gray-700"
          }`}
        >
          Fitness Plan
        </button>
      </div>

      <div className="bg-white p-6 rounded-lg shadow-md">
        {activeTab === "diet" ? (
          <div className="prose max-w-none">
            <div dangerouslySetInnerHTML={{ __html: plan.dietPlan }} />
          </div>
        ) : (
          <div className="prose max-w-none">
            <div dangerouslySetInnerHTML={{ __html: plan.fitnessPlan }} />
          </div>
        )}
      </div>
    </div>
  );
}