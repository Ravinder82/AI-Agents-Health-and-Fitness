// Environment configuration
export const env = {
  GEMINI_API_KEY: import.meta.env.VITE_GEMINI_API_KEY || '',
} as const;

// Validate that required environment variables are set
export function validateEnv() {
  const missing = [] as string[];

  if (!env.GEMINI_API_KEY) {
    missing.push('VITE_GEMINI_API_KEY');
  }

  return {
    isValid: missing.length === 0,
    missing,
  };
}