import { useState } from 'react';
import { UserProfile, HealthPlan } from '@/types/user';
import { generateHealthPlan } from '@/lib/gemini';

export function useHealthPlan() {
  const [healthPlan, setHealthPlan] = useState<HealthPlan | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function generatePlan(apiKey: string, data: UserProfile) {
    if (!apiKey) {
      setError("Please enter your Google Gemini API key");
      return;
    }

    setLoading(true);
    setError(null);

    try {
      const plan = await generateHealthPlan(apiKey, data);
      setHealthPlan(plan);
    } catch (err) {
      setError("Failed to generate health plan. Please check your API key and try again.");
      console.error(err);
    } finally {
      setLoading(false);
    }
  }

  return {
    healthPlan,
    loading,
    error,
    generatePlan,
  };
}