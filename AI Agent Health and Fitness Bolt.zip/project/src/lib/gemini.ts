import { GoogleGenerativeAI } from "@google/generative-ai";
import { UserProfile } from "@/types/user";
import { createDietPrompt, createFitnessPrompt } from "@/lib/prompts";

export async function generateHealthPlan(apiKey: string, userProfile: UserProfile) {
  try {
    const genAI = new GoogleGenerativeAI(apiKey);
    const model = genAI.getGenerativeModel({ model: "gemini-1.5-flash-latest" });

    const [dietResult, fitnessResult] = await Promise.all([
      model.generateContent(createDietPrompt(userProfile)),
      model.generateContent(createFitnessPrompt(userProfile)),
    ]);

    return {
      dietPlan: dietResult.response.text(),
      fitnessPlan: fitnessResult.response.text(),
    };
  } catch (error) {
    console.error("Error generating health plan:", error);
    throw error;
  }
}