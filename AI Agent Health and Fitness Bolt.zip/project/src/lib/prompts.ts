import { UserProfile } from "@/types/user";

export function createDietPrompt(userProfile: UserProfile): string {
  return `
    Create a comprehensive daily meal plan based on this user profile:
    Age: ${userProfile.age}
    Weight: ${userProfile.weight}kg
    Height: ${userProfile.height}cm
    Sex: ${userProfile.sex}
    Activity Level: ${userProfile.activityLevel}
    Fitness Goals: ${userProfile.fitnessGoals}

    Please provide:
    1. Breakfast plan with nutritional breakdown
    2. Lunch recommendations
    3. Dinner suggestions
    4. Healthy snack options
    5. Total estimated daily calories
    6. Key nutritional considerations

    Format the response in markdown.
  `;
}

export function createFitnessPrompt(userProfile: UserProfile): string {
  return `
    Design a workout routine based on this user profile:
    Age: ${userProfile.age}
    Weight: ${userProfile.weight}kg
    Height: ${userProfile.height}cm
    Sex: ${userProfile.sex}
    Activity Level: ${userProfile.activityLevel}
    Fitness Goals: ${userProfile.fitnessGoals}

    Please provide:
    1. Warm-up exercises (5-10 minutes)
    2. Main workout routine targeting specific fitness goals
    3. Cool-down and stretching
    4. Recommended workout frequency
    5. Safety tips and modifications
    6. Progress tracking suggestions

    Format the response in markdown.
  `;
}