export interface UserProfile {
  age: number;
  weight: number;
  height: number;
  sex: string;
  activityLevel: string;
  fitnessGoals: string;
}

export interface HealthPlan {
  dietPlan: string;
  fitnessPlan: string;
}